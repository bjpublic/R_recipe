f5 <- function(){
	"i am f5 function"
}

f6 <- function(){
	"i am f6 function"
}

f7 <- function(){
	"i am f7 function"
}

f8 <- function(){
	"i am f8 function"
}

f9 <- function(){
	"i am f9 function"
}